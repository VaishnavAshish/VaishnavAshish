<!DOCTYPE html>
<html lang="en">
	<head>
	  <title>Navigation</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="google-signin-client_id" content="214155233946-n3vsd276lrd5tno5m00nd7k4f1h5id32.apps.googleusercontent.com">
	  <link rel="stylesheet" href="style/style.css">
	  <link rel="stylesheet" href="style/css/bootstrap.min.css">
	  <script src="style/js/jquery.min.js"></script>
	  <script src="style/js/bootstrap.min.js"></script>
	
<script>


</script>
	</head>
	

<body>

<!--Header-->	
<div id="header">
<?php include("header.php");?>	
</div>
<!--/Header-->
<br><br>

<div class="container" >			
	<div style="padding:0 70px 0 70px;">
       <h1 style="text-align:center; color:#031658; text-decoration:underline;">About Us</h1>
	   <br>
	   <p style="font-size:25px;" >
			We at padhlepappu.com believe in hard work and dedication and we want to provide platform to those students who have the dream to get the government jobs through their own preparation. 
			We have tried to make our website easy, appropriate and relevant so that we can fulfill the aspiration of all the candidates who are looking for an ultimate solution of their all problems related to written exams. 
	   </p>
	</div>
</div>



<!--Footer-->	
<?php include("footer.php");?>	
<!--/Footer-->
		<script src="https://apis.google.com/js/client:platform.js?onload=renderButton" async defer></script>
       </body>
 </html>
