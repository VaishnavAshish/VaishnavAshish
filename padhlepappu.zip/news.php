<link rel="stylesheet" href="style/css/news_scroll.css" type="text/css">
<!--NEWS-->
<div class="col-sm-4 col-xs-12" style="max-width:100%; ">
			<div class="col-xs-4" style="border:solid; background-color:white; height:560px; padding:0px; border:1; width:100%;"> 
				<div  class="col-xs-12"  style="background-color:#031658; height:35px; width:100%; color:white;">
					<h4  style="text-align:center;">Latest News<h4>
				</div>
					<iframe name="NewsIFrame" src="news_scroll.php" frameborder="0" scrolling="no"></iframe>
			</div>
		</div>
<!--/NEWS-->
		